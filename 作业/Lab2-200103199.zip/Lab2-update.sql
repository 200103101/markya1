UPDATE customer SET c_acctbal = 99999.00
WHERE c_mktsegment = "Finance";

UPDATE customer SET c_address = "K street"
WHERE c_name = "James Pyn";

UPDATE customer SET c_phone = "555-321-0000"
WHERE c_name = "Alice Williams";

UPDATE customer SET c_phone = "555-129-0302"
WHERE c_name = "John Smith";