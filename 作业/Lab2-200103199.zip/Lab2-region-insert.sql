INSERT INTO region (r_regionkey, r_name) VALUES 
(0, "AFRICA"), (1, "AMERICA"), (2, "ASIA"), (3, "EUROPE"), (4, "MIDDLE EAST");