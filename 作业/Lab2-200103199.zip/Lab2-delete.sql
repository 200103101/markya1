DELETE FROM customer
WHERE c_mktsegment = "Account" OR c_acctbal > 8500;