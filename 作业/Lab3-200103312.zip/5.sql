SELECT p_type, COUNT(*) FROM part
WHERE p_type LIKE '%NICKEL%'
GROUP BY p_type ORDER BY p_type;