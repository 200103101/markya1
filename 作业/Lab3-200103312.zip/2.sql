SELECT s_name, s_acctbal FROM supplier
ORDER BY s_acctbal DESC, s_name ASC
LIMIT 1;