SELECT c_mktsegment, MIN(c_acctbal), MAX(c_acctbal), AVG(c_acctbal), SUM(c_acctbal) as sum_bal FROM customer
GROUP BY c_mktsegment
ORDER BY sum_bal DESC;