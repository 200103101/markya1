SELECT ROUND(SUM(p_retailprice))
FROM part WHERE p_retailprice < 2000 AND p_mfgr IN ( 'Manufacturer#1', 'Manufacturer#2', 'Manufacturer#3', 'Manufacturer#4', 'Manufacturer#5', 'Manufacturer#6');