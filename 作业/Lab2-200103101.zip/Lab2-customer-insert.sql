INSERT INTO customer VALUES(0, "John Smith", "5th street", 3, "456-129-0302", 1000.67, "Finance", "any comment"),
(1, "Joe Brown", "9th street", 4, "234-957-3929", 83849.45, "Sales", "any comment"),
(2, "Alice Williams", "G street", 0, "345-321-0000", 9999.90, "Science", "any comment"),
(3, "Ashley Johnson", "Main street", 1, "567-222-0945", 34093.11, "Finance", "any comment"),
(4, "James Pyn", "12th street", 1, "234-899-8695", 1229.00, "Account", "any comment");