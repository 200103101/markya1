SELECT l_orderkey,l_extendedprice*(1-l_discount) FROM lineitem
WHERE l_shipdate <> '1994-11-28'
ORDER BY l_extendedprice*(1-l_discount) DESC, l_orderkey LIMIT 1;